# Project Report: Smart Weather & Travel Dashboard

## 1. Objective
Build a responsive web app that fetches real-time weather and turns it into practical travel advice.

## 2. Technology
HTML5, CSS3 (Grid, Flexbox, media queries, keyframe animations), ES6+ JavaScript (async/await, fetch, destructuring, template literals, array methods), Open-Meteo REST APIs, Git and GitHub.

## 3. Architecture
Three layers keep concerns separate:
1. Data (`api.js`): geocodes the city, requests current and daily data, reshapes the API's parallel arrays into one object per day.
2. Logic (`travel.js`): `rateDay()` turns a day's rain chance, temperature, wind, UV and weather code into activity ratings and a pack list. `bestDay()` scores each day (dry, mild, calm) and picks the highest.
3. UI (`app.js`): validates input, renders results with DOM methods, handles events.

## 4. Features
City search, 7-day forecast, animated weather icons, travel suggestions, pack list, best-day recommendation, unit toggle, recent searches.

## 5. Error handling
Empty or invalid input, unknown city, API error status, and network failure each show a specific message.

## 6. Testing (fill in your results)
- Valid cities (Chennai, Goa, London, Tokyo)
- Invalid input ("", "a", "123", "Chennai!!")
- Unknown city ("Xqzvbn")
- Offline mode
- Screen widths 360px, 768px, 1280px
- Rainy and hot-weather cities, to check suggestions change

## 7. Challenges and learning
(Write your own: for example handling asynchronous errors, reshaping API data, designing the scoring rules.)

## 8. Future improvements
Hourly forecast, saving favourite cities, map view, air-quality data, user-adjustable preferences.
