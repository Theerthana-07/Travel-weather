// Travel recommendation rules. Pure functions: no DOM access, easy to test.
// A "day" is { code, max, min, rain (%), uv, wind (km/h) }.

function rateDay(day) {
  const { code, max, min, rain, uv, wind } = day;
  const storm = code >= 95, wet = rain >= 50, hot = max >= 35, cold = max <= 8;
  const A = (name, icon, level, why) => ({ name, icon, level, why });

  const activities = [
    storm || wet ? A("Sightseeing", "🏛️", "skip", "Rain is likely, so outdoor sights will be unpleasant.")
      : hot ? A("Sightseeing", "🏛️", "ok", "Very hot. Go early morning or after sunset.")
      : cold ? A("Sightseeing", "🏛️", "ok", "Cold day. Dress warmly and keep walks short.")
      : A("Sightseeing", "🏛️", "great", "Comfortable and mostly dry. Good for walking around."),

    storm || rain >= 40 ? A("Beach", "🏖️", "skip", "Rain or storms expected.")
      : max >= 28 && wind < 30 ? A("Beach", "🏖️", "great", "Warm, dry and calm. A good beach day.")
      : max >= 24 ? A("Beach", "🏖️", "ok", "Pleasant, though breezy or mild for swimming.")
      : A("Beach", "🏖️", "skip", "Too cool for the beach."),

    storm || rain >= 40 || max <= 5 ? A("Hiking", "🥾", "skip", "Wet or too cold, and trails can be slippery or unsafe.")
      : max >= 33 || wind >= 35 ? A("Hiking", "🥾", "ok", max >= 33 ? "Hot. Start at sunrise and carry extra water." : "Strong winds on exposed trails.")
      : A("Hiking", "🥾", "great", "Dry and mild. Good conditions for a trail."),

    storm || wet || hot || cold ? A("Museums & indoor", "🎭", "great", "A comfortable way to spend the day out of the weather.")
      : A("Museums & indoor", "🎭", "ok", "Fine, but the weather suits outdoor plans better."),

    storm ? A("Markets & street food", "🍜", "skip", "Stalls are likely to be closed in a storm.")
      : wet ? A("Markets & street food", "🍜", "ok", "Expect wet streets. Pick covered markets.")
      : A("Markets & street food", "🍜", "great", "Good weather for browsing and eating outdoors.")
  ];

  const pack = [];
  if (rain >= 40) pack.push("Umbrella or raincoat, and waterproof footwear");
  if (uv >= 6) pack.push("Sunscreen, sunglasses and a hat (UV index " + Math.round(uv) + ")");
  if (max >= 30) pack.push("Light cotton clothes and a water bottle");
  if (max >= 35) pack.push("Electrolytes or ORS, and avoid midday outdoor plans");
  if (min <= 12) pack.push("A warm jacket for the evening");
  if (min <= 3) pack.push("Gloves and a beanie");
  if (wind >= 30) pack.push("A windbreaker; secure hats and loose items");
  if (!pack.length) pack.push("Comfortable walking shoes and a light layer");

  const alert = storm ? "Thunderstorm forecast. Avoid outdoor activities and check transport delays." : "";
  return { activities, pack, alert };
}

// Higher score = better day to travel (dry, mild, calm).
function dayScore(d) {
  return 100 - d.rain - Math.abs(d.max - 26) * 2 - d.wind * 0.5 - (d.code >= 95 ? 40 : 0);
}
function bestDay(days) {
  return days.reduce((best, d) => (dayScore(d) > dayScore(best) ? d : best), days[0]);
}
if (typeof module !== "undefined") module.exports = { rateDay, dayScore, bestDay };
