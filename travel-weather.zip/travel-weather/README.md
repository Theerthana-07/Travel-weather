# Smart Weather & Travel Dashboard

Search a city, see current weather and a 7-day forecast, and get travel suggestions for any day you select.

## Features
- City search (Open-Meteo geocoding API) with input validation and clear error messages
- Current conditions plus a 7-day forecast (high/low, rain chance)
- Dynamic weather icons: animated per condition, with day/night themed backgrounds
- Travel suggestions per day: ratings for sightseeing, beach, hiking, indoor and food, a pack list, storm alerts and a "best day to travel" pick
- °C/°F toggle, recent searches, loading state, responsive layout

## Run
Open `index.html` in a browser (internet required). No API key or install needed.

## Structure
- `api.js`: API calls and weather-code mapping
- `travel.js`: travel rules and scoring (pure functions)
- `app.js`: validation, rendering, events
- `style.css`: layout, themes, icon animations
- `REPORT.md`: project report

## Deploy
Push to GitHub, then Settings > Pages > Deploy from branch (`main`, root).
