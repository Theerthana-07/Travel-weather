// API layer: Open-Meteo geocoding + forecast (free, no key).
const GEO_URL = "https://geocoding-api.open-meteo.com/v1/search";
const WEATHER_URL = "https://api.open-meteo.com/v1/forecast";

// WMO weather code -> [description, emoji, theme]
const CODES = {
  0: ["Clear sky", "☀️", "clear"], 1: ["Mainly clear", "🌤️", "clear"], 2: ["Partly cloudy", "⛅", "cloudy"],
  3: ["Overcast", "☁️", "cloudy"], 45: ["Fog", "🌫️", "cloudy"], 48: ["Freezing fog", "🌫️", "cloudy"],
  51: ["Light drizzle", "🌦️", "rain"], 53: ["Drizzle", "🌦️", "rain"], 55: ["Heavy drizzle", "🌧️", "rain"],
  61: ["Light rain", "🌧️", "rain"], 63: ["Rain", "🌧️", "rain"], 65: ["Heavy rain", "🌧️", "rain"],
  71: ["Light snow", "🌨️", "snow"], 73: ["Snow", "🌨️", "snow"], 75: ["Heavy snow", "❄️", "snow"],
  80: ["Rain showers", "🌦️", "rain"], 81: ["Heavy showers", "🌧️", "rain"], 82: ["Violent showers", "🌧️", "rain"],
  95: ["Thunderstorm", "⛈️", "storm"], 96: ["Thunderstorm, hail", "⛈️", "storm"], 99: ["Severe thunderstorm", "⛈️", "storm"]
};
const codeInfo = (c) => CODES[c] || ["Unknown", "🌡️", "clear"];

async function getJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`The weather service returned an error (${res.status}). Try again later.`);
  return res.json();
}

async function fetchWeather(city) {
  const geo = await getJSON(`${GEO_URL}?name=${encodeURIComponent(city)}&count=1&language=en&format=json`);
  if (!geo.results || !geo.results.length) throw new Error(`No city found for "${city}". Check the spelling.`);
  const { latitude, longitude, name, admin1, country } = geo.results[0];
  const params = new URLSearchParams({
    latitude, longitude, timezone: "auto", forecast_days: 7,
    current: "temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code,is_day",
    daily: "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max,wind_speed_10m_max"
  });
  const w = await getJSON(`${WEATHER_URL}?${params}`);
  const d = w.daily;
  // Reshape the API's parallel arrays into one object per day
  const days = d.time.map((date, i) => ({
    date, code: d.weather_code[i], max: d.temperature_2m_max[i], min: d.temperature_2m_min[i],
    rain: d.precipitation_probability_max[i] ?? 0, uv: d.uv_index_max[i] ?? 0, wind: d.wind_speed_10m_max[i] ?? 0
  }));
  return { place: [name, admin1, country].filter(Boolean).join(", "), current: w.current, days };
}
