// UI layer: validation, rendering, events.
const $ = (id) => document.getElementById(id);
const state = { data: null, unit: "c", sel: 0 };

const validate = (v) => {
  const c = v.trim();
  if (!c) return "Please enter a city name.";
  if (c.length < 2) return "City name is too short.";
  if (!/^[\p{L}\s.'-]+$/u.test(c)) return "Use letters only (no numbers or symbols).";
  return "";
};
const temp = (c) => state.unit === "c" ? `${Math.round(c)}°` : `${Math.round(c * 9 / 5 + 32)}°`;
const unitTemp = (c) => temp(c) + state.unit.toUpperCase();
const speed = (k) => state.unit === "c" ? `${Math.round(k)} km/h` : `${Math.round(k * 0.621371)} mph`;
const animFor = (theme) => ({ clear: "spin", cloudy: "float", rain: "bob", snow: "bob", storm: "flash" })[theme] || "";
const dayLabel = (d, i) => i === 0 ? "Today" : new Date(d.date + "T00:00").toLocaleDateString(undefined, { weekday: "short" });

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined) e.textContent = text;
  return e;
}

function renderNow() {
  const { place, current: c } = state.data;
  const [desc, icon, theme] = codeInfo(c.weather_code);
  const night = c.is_day === 0;
  $("place").textContent = place;
  $("desc").textContent = desc;
  $("icon").textContent = night && theme === "clear" ? "🌙" : icon;
  $("icon").className = "icon " + animFor(theme);
  $("temp").textContent = unitTemp(c.temperature_2m);
  $("feels").textContent = unitTemp(c.apparent_temperature);
  $("humidity").textContent = c.relative_humidity_2m + "%";
  $("wind").textContent = speed(c.wind_speed_10m);
  document.body.className = night ? "night" : theme;
}

function renderForecast() {
  $("forecast").replaceChildren(...state.data.days.map((d, i) => {
    const b = el("button", "day");
    b.type = "button";
    b.setAttribute("aria-pressed", i === state.sel);
    b.append(el("b", "", dayLabel(d, i)), el("span", "e", codeInfo(d.code)[1]),
      el("span", "", `${temp(d.max)} / ${temp(d.min)}`), el("small", "", `${d.rain}% rain`));
    b.addEventListener("click", () => { state.sel = i; renderForecast(); renderTravel(); });
    return b;
  }));
}

function renderTravel() {
  const { days } = state.data;
  const d = days[state.sel];
  const r = rateDay(d);
  const best = bestDay(days);
  $("dayName").textContent = `${dayLabel(d, state.sel)} (${codeInfo(d.code)[0].toLowerCase()})`;
  $("best").textContent = best === d
    ? "This is the best day of the week to travel."
    : `Best day to travel this week: ${dayLabel(best, days.indexOf(best))} (${codeInfo(best.code)[0].toLowerCase()}, ${best.rain}% rain).`;
  $("alert").hidden = !r.alert;
  $("alert").textContent = r.alert;
  const label = { great: "Great", ok: "Okay", skip: "Skip" };
  $("acts").replaceChildren(...r.activities.map((a) => {
    const c = el("article", "act " + a.level);
    c.append(el("h4", "", `${a.icon} ${a.name}`), el("span", "lv", label[a.level]), el("p", "", a.why));
    return c;
  }));
  $("pack").replaceChildren(...r.pack.map((p) => el("li", "", p)));
}

const renderAll = () => { renderNow(); renderForecast(); renderTravel(); $("result").hidden = false; };

function showError(msg) {
  $("error").textContent = msg;
  $("city").setAttribute("aria-invalid", msg ? "true" : "false");
}

async function search(city) {
  const problem = validate(city);
  showError(problem);
  if (problem) return;
  $("loading").hidden = false;
  $("result").hidden = true;
  try {
    state.data = await fetchWeather(city.trim());
    state.sel = 0;
    renderAll();
    saveRecent(state.data.place.split(",")[0]);
  } catch (err) {
    showError(err instanceof TypeError ? "Network problem. Check your internet connection and try again." : err.message);
  } finally {
    $("loading").hidden = true;
  }
}

function saveRecent(name) {
  try {
    const list = [name, ...JSON.parse(localStorage.getItem("recent") || "[]").filter((n) => n !== name)].slice(0, 5);
    localStorage.setItem("recent", JSON.stringify(list));
    drawRecent();
  } catch (e) { /* storage unavailable */ }
}
function drawRecent() {
  let list = [];
  try { list = JSON.parse(localStorage.getItem("recent") || "[]"); } catch (e) {}
  $("recent").replaceChildren(...list.map((n) => {
    const b = el("button", "", n);
    b.type = "button";
    b.addEventListener("click", () => { $("city").value = n; search(n); });
    return b;
  }));
}

$("searchForm").addEventListener("submit", (e) => { e.preventDefault(); search($("city").value); });
document.querySelectorAll(".units button").forEach((b) => b.addEventListener("click", () => {
  state.unit = b.dataset.u;
  document.querySelectorAll(".units button").forEach((x) => x.setAttribute("aria-pressed", x === b));
  if (state.data) renderAll();
}));
drawRecent();
